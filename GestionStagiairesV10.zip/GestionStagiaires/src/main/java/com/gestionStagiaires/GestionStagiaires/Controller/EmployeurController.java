package com.gestionStagiaires.GestionStagiaires.Controller;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Model.Domaines;
import com.gestionStagiaires.GestionStagiaires.Model.Employeur;
import com.gestionStagiaires.GestionStagiaires.Model.OffreDeStage;
import com.gestionStagiaires.GestionStagiaires.Service.EmployeurService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController //Pour que Spring le considère cette classe comme un controlleur, donc il peut exposer une ressource
@RequestMapping("/employeur")
@AllArgsConstructor
public class EmployeurController {

    private final EmployeurService employeurService;

    @PostMapping("/create") //Pour le mapper à un verbe HTTP
    public Employeur create(@RequestBody Employeur employeur) { //@RequestBody Pour que Spring puisse envoyer des données au body de la requette
        return employeurService.creer(employeur);
    }

    @GetMapping("/read")
    public List<Employeur> read() {
        return employeurService.lire();
    }

    @GetMapping("/read/{id}")
    public Employeur getById(@PathVariable long id) {
        return employeurService.getById(id);
    }

    @PutMapping("/update/{id}")
    public Employeur update(@PathVariable long id, @RequestBody Employeur employeur) {
        return employeurService.modifier(id, employeur);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        return employeurService.supprimer(id);
    }

    @GetMapping("/getByEmail/{email}")
    public Employeur getByEmail(@PathVariable String email) {
        return employeurService.getByEmail(email);
    }

    @GetMapping("/getDomaines")
    public Domaines[] getDomaines() {
        return employeurService.getDomaines();
    }

    @GetMapping("/getCandidatures/{id}")
    public List<Candidature> getCandidatures(@PathVariable Long id) {
        return employeurService.getCandidatures(id);
    }

    @PostMapping("/addOffre/{id}")
    public Employeur addOffre(@PathVariable Long id, @RequestBody OffreDeStage offre) {
        return employeurService.addOffre(id, offre);
    }
}

