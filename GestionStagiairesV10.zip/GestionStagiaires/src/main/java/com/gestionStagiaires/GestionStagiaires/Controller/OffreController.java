package com.gestionStagiaires.GestionStagiaires.Controller;

import com.gestionStagiaires.GestionStagiaires.Model.OffreDeStage;
import com.gestionStagiaires.GestionStagiaires.Service.OffreService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController //Pour que Spring le considère cette classe comme un controlleur, donc il peut exposer une ressource
@RequestMapping("/offre")
@AllArgsConstructor
public class OffreController {

    private final OffreService offreService;

    @PostMapping("/create") //Pour le mapper à un verbe HTTP
    public OffreDeStage create(@RequestBody OffreDeStage offreDeStage) { //@RequestBody Pour que Spring puisse envoyer des données au body de la requette
        return offreService.creer(offreDeStage);
    }

    @GetMapping("/read/{id}")
    public OffreDeStage getById(@PathVariable long id) {
        return offreService.getById(id);
    }

    @GetMapping("/read")
    public List<OffreDeStage> read() {
        return offreService.lire();
    }

    @PutMapping("/update/{id}")
    public OffreDeStage update(@PathVariable long id, @RequestBody OffreDeStage offreDeStage) {
        return offreService.modifier(id, offreDeStage);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        return offreService.supprimer(id);
    }
}
