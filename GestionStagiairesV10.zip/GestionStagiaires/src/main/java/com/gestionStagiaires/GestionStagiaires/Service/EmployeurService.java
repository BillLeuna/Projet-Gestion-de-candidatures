package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Model.Domaines;
import com.gestionStagiaires.GestionStagiaires.Model.Employeur;
import com.gestionStagiaires.GestionStagiaires.Model.OffreDeStage;

import java.util.List;

public interface EmployeurService {
    Employeur creer(Employeur employeur);

    List<Employeur> lire();

    Employeur getById(Long id);

    Employeur modifier(Long id, Employeur employeur);

    String supprimer(Long id);

    Employeur getByEmail(String email);

    public Domaines[] getDomaines();

    public List<Candidature> getCandidatures(Long employeurId);

    public Employeur addOffre(Long employeurId, OffreDeStage offre);

}
