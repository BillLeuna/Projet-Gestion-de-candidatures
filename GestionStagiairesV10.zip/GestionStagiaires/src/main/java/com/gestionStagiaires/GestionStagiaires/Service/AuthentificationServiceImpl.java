package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Authentification;
import com.gestionStagiaires.GestionStagiaires.Repository.AuthentificationRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service //pour définir cette classe comme étant une classe contenant du code métier donc un service
@AllArgsConstructor //Pour demander à Lombok de créer un contructeur avec tous les champs qui sont dans cette classe
public class AuthentificationServiceImpl implements AuthentificationService{

    private final AuthentificationRepository authentificationRepository;

    @Override
    public Authentification creer(Authentification authentification) {
        return authentificationRepository.save(authentification);
    }

    @Override
    public List<Authentification> lire() {
        return authentificationRepository.findAll();
    }

    @Override
    public Authentification getById(Long id) {
        return authentificationRepository.findById(id).orElseThrow(() -> new RuntimeException("Compte non trouvé !"));
    }

    @Override
    public Boolean modifier(Authentification authentification) {
        AtomicReference<Boolean> changeOk = new AtomicReference<>(false);
        authentificationRepository.findAll().forEach(authentificationElement -> {
            if(authentificationElement.getEmail().equals(authentification.getEmail())) {
                authentificationElement.setMotDePasse(authentification.getMotDePasse());
                changeOk.set(true);
            }
        });
        return changeOk.get();
    }

    @Override
    public String supprimer(Long id) {
        authentificationRepository.deleteById(id);
        return "Compte supprimé !";
    }

    @Override
    public Boolean authentifier(Authentification authentification) {
        AtomicReference<Boolean> authentificationOk = new AtomicReference<>(false);
        authentificationRepository.findAll().forEach(authentificationElement -> {
            if(authentificationElement.getEmail().equals(authentification.getEmail()) && authentificationElement.getMotDePasse().equals(authentification.getMotDePasse()))
                authentificationOk.set(true);
        });
        return authentificationOk.get();
    }

    @Override
    public Boolean verifyIfEmailExists(String email) {
        AtomicReference<Boolean> authentificationOk = new AtomicReference<>(false);
        authentificationRepository.findAll().forEach(authentificationElement -> {
            if(authentificationElement.getEmail().equals(email))
                authentificationOk.set(true);
        });
        return authentificationOk.get();
    }

    @Override
    public Boolean deleteByEmail(String email) {
        AtomicReference<Boolean> deleteOk = new AtomicReference<>(false);
        authentificationRepository.findAll().forEach(authentificationElement -> {
            if(authentificationElement.getEmail().equals(email))
                authentificationRepository.delete(authentificationElement);
                deleteOk.set(true);
        });
        return deleteOk.get();
    }
}
