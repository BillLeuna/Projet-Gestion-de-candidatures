package com.gestionStagiaires.GestionStagiaires.Model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "CANDIDATURE")
@Getter
@Setter
@NoArgsConstructor
public class Candidature {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "etudiant_id")
	private Etudiant etudiant;

	private enum StatutEnum { acceptée, enAttente }

	private StatutEnum statut;

	@ManyToOne
	@JoinColumn(name = "employeur_id")
	private Employeur employeur;

	@OneToOne
	@JoinColumn(name = "CV_id")
	private FileDB cv;

	@OneToOne
	@JoinColumn(name = "lettre_de_motivation_id")
	private FileDB lettreDeMotivation;

	@ManyToOne
	@JoinColumn(name = "offre_de_stage_id")
	private OffreDeStage offre;

}
