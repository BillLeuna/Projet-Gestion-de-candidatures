package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Etudiant;
import com.gestionStagiaires.GestionStagiaires.Model.FileDB;
import com.gestionStagiaires.GestionStagiaires.Repository.FileDBRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;

import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@Service //pour définir cette classe comme étant une classe contenant du code métier donc un service
@AllArgsConstructor //Pour demander à Lombok de créer un contructeur avec tous les champs qui sont dans cette classe
public class FileDBServiceImpl implements FileDBService{

    private FileDBRepository fileDBRepository;

    @Override
    public FileDB store(MultipartFile file) throws IOException {
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        FileDB fileDB = new FileDB();
        fileDB.setName(fileName);
        fileDB.setType(file.getContentType());
        fileDB.setData(file.getBytes());

        return fileDBRepository.save(fileDB);
    }

    @Override
    public FileDB getFile(Long id) {
        return fileDBRepository.findById(String.valueOf(id)).get();
    }

    @Override
    public Stream<FileDB> getAllFiles() {
        return fileDBRepository.findAll().stream();
    }

    @Override
    public FileDB getByname(String name) {
        AtomicReference<FileDB> file = new AtomicReference<>();
        fileDBRepository.findAll().forEach(fileElement -> {
            if(fileElement.getName() != null) {
                if(fileElement.getName().equals(name))
                    file.set(fileElement);
            }
        });
        return file.get();
    }
}
