package com.gestionStagiaires.GestionStagiaires.Model;


import java.util.List;

public enum Domaines {
	immobilier("Immobilier"), ingenierieInformatique("Ingenierie Informatique"), ingenierieBiomedicale("Ingenierie Biometrique"), management("Management"); //liste à compléter
	String enumString;
	Domaines(String enumString) {
		this.enumString = enumString;
	}
	String getEnumString() {
		return enumString;
	}
}
