package com.gestionStagiaires.GestionStagiaires.Repository;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidatureRepository extends JpaRepository<Candidature, Long>{
}
