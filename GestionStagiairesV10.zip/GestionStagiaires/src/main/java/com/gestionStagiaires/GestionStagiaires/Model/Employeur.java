package com.gestionStagiaires.GestionStagiaires.Model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "EMPLOYEUR")
@Getter
@Setter
@NoArgsConstructor
public class Employeur {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(length = 150)
	private String nom, description, email;

	private Domaines domaine;
//	private String domaineString = domaine.getEnumString();

	@OneToOne
	@JoinColumn(name = "logo_id")
	private FileDB logo;

	@OneToMany (targetEntity = Candidature.class , cascade = CascadeType.ALL)
	@JoinColumn(name = "candidature_id", referencedColumnName = "id")
	private List<Candidature> candidatures;

	@OneToMany (targetEntity = OffreDeStage.class , cascade = CascadeType.ALL)
	@JoinColumn(name = "offre_id", referencedColumnName = "id")
	private List<OffreDeStage> offresDeStage;
	
}
