package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.OffreDeStage;

import java.util.List;

public interface OffreService {
    OffreDeStage creer(OffreDeStage offreDeStage);

    List<OffreDeStage> lire();

    OffreDeStage getById(Long id);

    OffreDeStage modifier(Long id, OffreDeStage offreDeStage);

    String supprimer(Long id);
}