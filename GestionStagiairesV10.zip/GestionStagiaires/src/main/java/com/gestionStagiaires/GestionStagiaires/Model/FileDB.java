package com.gestionStagiaires.GestionStagiaires.Model;

import javax.persistence.*;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "FILE")
@Getter
@Setter
@NoArgsConstructor
public class FileDB {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "type")
    private String type;

    @Lob
    private byte[] data;

/*    @OneToOne
    @JoinColumn(name = "employeur_id")
    private Employeur employeur;*/
}


