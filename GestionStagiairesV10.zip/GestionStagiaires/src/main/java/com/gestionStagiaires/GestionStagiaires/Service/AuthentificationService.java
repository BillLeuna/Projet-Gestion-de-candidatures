package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Authentification;
import com.gestionStagiaires.GestionStagiaires.Model.Employeur;

import java.util.List;

public interface AuthentificationService {

    Authentification creer(Authentification authentification);

    List<Authentification> lire();

    Authentification getById(Long id);


    Boolean modifier(Authentification authentification);

    String supprimer(Long id);

    Boolean authentifier(Authentification authentification);

    Boolean verifyIfEmailExists(String email);

    Boolean deleteByEmail(String email);
}
