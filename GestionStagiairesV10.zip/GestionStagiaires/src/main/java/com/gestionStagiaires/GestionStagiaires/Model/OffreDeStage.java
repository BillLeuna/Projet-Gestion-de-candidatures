package com.gestionStagiaires.GestionStagiaires.Model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "OFFRE")
@Getter
@Setter
@NoArgsConstructor
public class OffreDeStage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String titre;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "employeur_id")
	private Employeur employeur;

	private String description;
	private Date dateDeDebut;
	private Domaines domaine;

	//private Long offre_de_stage_id;

	//private String domaineString = domaine.getEnumString();

/*	@OneToOne
	@JoinColumn(name = "candidature_id")
	private Candidature candidature;*/
}
