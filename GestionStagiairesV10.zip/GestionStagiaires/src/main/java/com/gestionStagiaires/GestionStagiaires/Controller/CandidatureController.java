package com.gestionStagiaires.GestionStagiaires.Controller;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Service.CandidatureService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController //Pour que Spring le considère cette classe comme un controlleur, donc il peut exposer une ressource
@RequestMapping("/candidature")
@AllArgsConstructor
public class CandidatureController {

    private final CandidatureService candidatureService;

    @PostMapping("/create") //Pour le mapper à un verbe HTTP
    public Candidature create(@RequestBody Candidature candidature) { //@RequestBody Pour que Spring puisse envoyer des données au body de la requette
        return candidatureService.creer(candidature);
    }

    @GetMapping("/read")
    public List<Candidature> read() {
        return candidatureService.lire();
    }

    @GetMapping("/read/{id}")
    public Candidature getById(@PathVariable long id) {
        return candidatureService.getById(id);
    }

    @PutMapping("/update/{id}")
    public Candidature update(@PathVariable long id, @RequestBody Candidature candidature) {
        return candidatureService.modifier(id, candidature);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        return candidatureService.supprimer(id);
    }

    @GetMapping("getId/{email}/{offreId}")
    public int getId(@PathVariable String email, @PathVariable int offreId) {
        return candidatureService.getId(email, offreId);
    }
}
