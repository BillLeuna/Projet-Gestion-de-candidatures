package com.gestionStagiaires.GestionStagiaires.Repository;

import com.gestionStagiaires.GestionStagiaires.Model.Employeur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeurRepository extends JpaRepository<Employeur, Long> {
    //Cette interface sert à représenter des données pour l'employeur
}
