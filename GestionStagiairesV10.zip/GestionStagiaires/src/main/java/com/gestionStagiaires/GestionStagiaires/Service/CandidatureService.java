package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;

import java.util.List;

public interface CandidatureService {
    Candidature creer(Candidature candidature);

    List<Candidature> lire();

    Candidature getById(Long id);

    Candidature modifier(Long id, Candidature candidature);

    String supprimer(Long id);

    int getId(String etudiantEmail, int offreId);
}
