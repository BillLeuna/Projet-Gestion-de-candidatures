package com.gestionStagiaires.GestionStagiaires.Controller;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Model.Etudiant;
import com.gestionStagiaires.GestionStagiaires.Service.EtudiantService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController //Pour que Spring le considère cette classe comme un controlleur, donc il peut exposer une ressource
@RequestMapping("/etudiant")
@AllArgsConstructor
public class EtudiantController {

    private final EtudiantService etudiantService;

    @PostMapping("/create") //Pour le mapper à un verbe HTTP
    public Etudiant create(@RequestBody Etudiant etudiant) { //@RequestBody Pour que Spring puisse envoyer des données au body de la requette
        return etudiantService.creer(etudiant);
    }

    @GetMapping("/read/{id}")
    public Etudiant getById(@PathVariable long id) {
        return etudiantService.getById(id);
    }

    @GetMapping("/read")
    public List<Etudiant> read() {
        return etudiantService.lire();
    }

    @PutMapping("/update/{id}")
    public Etudiant update(@PathVariable long id, @RequestBody Etudiant etudiant) {
        return etudiantService.modifier(id, etudiant);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        return etudiantService.supprimer(id);
    }

    @GetMapping("/getByEmail/{email}")
    public Etudiant getByEmail(@PathVariable String email) {
        return etudiantService.getByEmail(email);
    }

    @GetMapping("/getCandidatures/{id}")
    public List<Candidature> getCandidatures(@PathVariable Long id) {
        return etudiantService.getCandidatures(id);
    }
}
