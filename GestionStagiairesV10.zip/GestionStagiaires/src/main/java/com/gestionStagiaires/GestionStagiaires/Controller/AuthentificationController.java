package com.gestionStagiaires.GestionStagiaires.Controller;


import com.gestionStagiaires.GestionStagiaires.Model.Authentification;
import com.gestionStagiaires.GestionStagiaires.Service.AuthentificationService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController //Pour que Spring le considère cette classe comme un controlleur, donc il peut exposer une ressource
@RequestMapping("/authentification")
@AllArgsConstructor
public class AuthentificationController {

    private final AuthentificationService authentificationService;

    @PostMapping("/create") //Pour le mapper à un verbe HTTP
    public Authentification create(@RequestBody Authentification authentification) { //@RequestBody Pour que Spring puisse envoyer des données au body de la requette
        return authentificationService.creer(authentification);
    }

    @GetMapping("/read")
    public List<Authentification> read() {
        return authentificationService.lire();
    }

    @GetMapping("/read/{id}")
    public Authentification getById(@PathVariable long id) {
        return authentificationService.getById(id);
    }

    @PutMapping("/update")
    public Boolean update(@RequestBody Authentification authentification) {
        return authentificationService.modifier(authentification);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        return authentificationService.supprimer(id);
    }

    @PostMapping("/authentify")
    public Boolean authentify(@RequestBody Authentification authentification) {
        return authentificationService.authentifier(authentification);
    }

    @PostMapping("/verifyIfEmailExists")
    public Boolean verifyIfEmailExists(@RequestBody String email) {
        return authentificationService.verifyIfEmailExists(email);
    }

    @DeleteMapping("deleteByEmail/{email}")
    public Boolean deleteByEmail(@PathVariable String email) {
        return authentificationService.deleteByEmail(email);
    }
}
