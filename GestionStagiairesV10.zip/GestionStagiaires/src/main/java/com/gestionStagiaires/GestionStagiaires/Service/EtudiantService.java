package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Model.Employeur;
import com.gestionStagiaires.GestionStagiaires.Model.Etudiant;

import java.util.List;

public interface EtudiantService {
    Etudiant creer(Etudiant etudiant);

    List<Etudiant> lire();

    Etudiant getById(Long id);

    Etudiant modifier(Long id, Etudiant etudiant);

    String supprimer(Long id);

    Etudiant getByEmail(String email);

    public List<Candidature> getCandidatures(Long etudiantId);
}
