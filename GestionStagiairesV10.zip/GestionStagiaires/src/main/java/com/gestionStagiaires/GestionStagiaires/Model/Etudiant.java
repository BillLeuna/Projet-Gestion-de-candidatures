package com.gestionStagiaires.GestionStagiaires.Model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "ETUDIANT")
@Getter
@Setter
@NoArgsConstructor
public class Etudiant {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(length = 150)
	private String nom, prenom, descriptionProfil, email, ecole;

	private Domaines domaine;
//	private String domaineString = domaine.getEnumString();

	private int anneeDEtude;

	@OneToMany (cascade = CascadeType.ALL)
	private List<Candidature> candidatures;
	
}
