package com.gestionStagiaires.GestionStagiaires.Service;

import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Model.Etudiant;
import com.gestionStagiaires.GestionStagiaires.Repository.EtudiantRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service //pour définir cette classe comme étant une classe contenant du code métier donc un service
@AllArgsConstructor //Pour demander à Lombok de créer un contructeur avec tous les champs qui sont dans cette classe
public class EtudiantServiceImpl implements EtudiantService{

    private final EtudiantRepository etudiantRepository;

    @Override
    public Etudiant creer(Etudiant etudiant) {
        return etudiantRepository.save(etudiant);
    }

    @Override
    public List<Etudiant> lire() {
        return etudiantRepository.findAll();
    }

    @Override
    public Etudiant getById(Long id) {
        return etudiantRepository.findById(id).orElseThrow(() -> new RuntimeException("Étudiant non trouvé !"));
    }

    @Override
    public Etudiant modifier(Long id, Etudiant etudiant) {
        return etudiantRepository.findById(id)
                .map(e-> {
                    e.setNom(etudiant.getNom());
                    e.setPrenom(etudiant.getPrenom());
                    e.setDescriptionProfil(etudiant.getDescriptionProfil());
                    e.setEmail(etudiant.getEmail());
                    e.setDomaine(etudiant.getDomaine());
                    e.setEcole(etudiant.getEcole());
                  //  e.setDomaineString(etudiant.getDomaineString());
                    e.setAnneeDEtude(etudiant.getAnneeDEtude());
                    e.setCandidatures(etudiant.getCandidatures());
                    return etudiantRepository.save(e);
                }).orElseThrow(() -> new RuntimeException("Étudiant non trouvé !"));
    }

    @Override
    public String supprimer(Long id) {
        etudiantRepository.deleteById(id);
        return "Étudiant supprimé";
    }

    @Override
    public Etudiant getByEmail(String email) {
        AtomicReference<Etudiant> etudiant = new AtomicReference<>();
        etudiantRepository.findAll().forEach(etudiantElement -> {
            if(etudiantElement.getEmail() != null) {
                if(etudiantElement.getEmail().equals(email))
                    etudiant.set(etudiantElement);
            }
        });
        return etudiant.get();
    }

    @Override
    public List<Candidature> getCandidatures(Long etudiantId) {
        return etudiantRepository.getById(etudiantId).getCandidatures();
    }
}
