package com.gestionStagiaires.GestionStagiaires.Service;


import com.gestionStagiaires.GestionStagiaires.Model.OffreDeStage;
import com.gestionStagiaires.GestionStagiaires.Repository.OffreRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service //pour définir cette classe comme étant une classe contenant du code métier donc un service
@AllArgsConstructor //Pour demander à Lombok de créer un contructeur avec tous les champs qui sont dans cette classe
public class OffreServiceImpl implements OffreService{
    //couche métier

    private final OffreRepository offreRepository;

    @Override
    public OffreDeStage creer(OffreDeStage offreDeStage) {
        return offreRepository.save(offreDeStage);
    }

    @Override
    public List<OffreDeStage> lire() {
        return offreRepository.findAll();
    }

    @Override
    public OffreDeStage getById(Long id) {
        return offreRepository.findById(id).orElseThrow(() -> new RuntimeException("Offre non trouvée !"));
    }

    @Override
    public OffreDeStage modifier(Long id, OffreDeStage offreDeStage) {
        return offreRepository.findById(id)
                .map(o-> {
                    o.setDescription(offreDeStage.getDescription());
                    o.setDateDeDebut(offreDeStage.getDateDeDebut());
                    o.setDomaine(offreDeStage.getDomaine());
                    o.setEmployeur(offreDeStage.getEmployeur());
                    o.setTitre(offreDeStage.getTitre());
                   // o.setDomaineString(offreDeStage.getDomaineString());
                    return offreRepository.save(o);
                }).orElseThrow(() -> new RuntimeException("Offre de stage non trouvée !"));
    }

    @Override
    public String supprimer(Long id) {
        offreRepository.deleteById(id);
        return "Offre de stage supprimée";
    }
}
