package com.gestionStagiaires.GestionStagiaires.Model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "AUTHENTIFICATION")
@Getter
@Setter
@NoArgsConstructor
public class Authentification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 150)
    private String email, motDePasse;

    private enum TypeAuthentification  { etudiant, employeur }

    private TypeAuthentification typeAuthentification;

}