package com.gestionStagiaires.GestionStagiaires.Service;


import com.gestionStagiaires.GestionStagiaires.Model.*;
import com.gestionStagiaires.GestionStagiaires.Repository.EmployeurRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service //pour définir cette classe comme étant une classe contenant du code métier donc un service
@AllArgsConstructor //Pour demander à Lombok de créer un contructeur avec tous les champs qui sont dans cette classe
public class EmployeurServiceImpl implements EmployeurService{
    //couche métier

    private final EmployeurRepository employeurRepository;

    @Override
    public Employeur creer(Employeur employeur) {
        return employeurRepository.save(employeur);
    }

    @Override
    public List<Employeur> lire() {
        return employeurRepository.findAll();
    }

    @Override
    public Employeur getById(Long id) {
        return employeurRepository.findById(id).orElseThrow(() -> new RuntimeException("Employeur non trouvé !"));
    }

    @Override
    public Employeur modifier(Long id, Employeur employeur) {
        return employeurRepository.findById(id)
                .map(e-> {
                    e.setNom(employeur.getNom());
                    e.setDescription(employeur.getDescription());
                    e.setEmail(employeur.getEmail());
                    e.setLogo(employeur.getLogo());
                    e.setDomaine(employeur.getDomaine());
                    e.setCandidatures(employeur.getCandidatures());
                    e.setOffresDeStage(employeur.getOffresDeStage());
                  //  e.setDomaineString(employeur.getDomaineString());
                    return employeurRepository.save(e);
                }).orElseThrow(() -> new RuntimeException("Employeur non trouvé !"));
    }

    @Override
    public Employeur addOffre(Long employeurId, OffreDeStage offre) {
        return employeurRepository.findById(employeurId)
                .map(e-> {
                    List<OffreDeStage> list = e.getOffresDeStage();
                    list.add(offre);
                    e.setOffresDeStage(list);
                    return employeurRepository.save(e);
                }).orElseThrow(() -> new RuntimeException("Employeur non trouvé !"));
    }

    @Override
    public String supprimer(Long id) {
        employeurRepository.deleteById(id);
        return "Employeur supprimé !";
    }

    @Override
    public Employeur getByEmail(String email) {
        AtomicReference<Employeur> employeur = new AtomicReference<>();
        employeurRepository.findAll().forEach(employeurElement -> {
            if(employeurElement.getEmail() != null) {
                if(employeurElement.getEmail().equals(email))
                    employeur.set(employeurElement);
            }
        });
        return employeur.get();
    }

    @Override
    public Domaines[] getDomaines() {
        return Domaines.values();
    }

    @Override
    public List<Candidature> getCandidatures(Long employeurId) {
        return employeurRepository.getById(employeurId).getCandidatures();
    }



}
