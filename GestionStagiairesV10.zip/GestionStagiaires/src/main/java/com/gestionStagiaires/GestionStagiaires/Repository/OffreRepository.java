package com.gestionStagiaires.GestionStagiaires.Repository;

import com.gestionStagiaires.GestionStagiaires.Model.OffreDeStage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OffreRepository extends JpaRepository<OffreDeStage, Long> {
}
