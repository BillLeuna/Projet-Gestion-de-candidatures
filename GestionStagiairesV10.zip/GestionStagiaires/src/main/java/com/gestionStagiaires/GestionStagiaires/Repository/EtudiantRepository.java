package com.gestionStagiaires.GestionStagiaires.Repository;

import com.gestionStagiaires.GestionStagiaires.Model.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EtudiantRepository extends JpaRepository<Etudiant, Long>{
}
