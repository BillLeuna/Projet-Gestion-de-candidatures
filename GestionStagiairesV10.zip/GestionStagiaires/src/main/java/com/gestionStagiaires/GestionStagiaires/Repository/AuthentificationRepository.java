package com.gestionStagiaires.GestionStagiaires.Repository;

import com.gestionStagiaires.GestionStagiaires.Model.Authentification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthentificationRepository extends JpaRepository<Authentification, Long> {
}
