package com.gestionStagiaires.GestionStagiaires.Service;


import com.gestionStagiaires.GestionStagiaires.Model.Candidature;
import com.gestionStagiaires.GestionStagiaires.Model.Employeur;
import com.gestionStagiaires.GestionStagiaires.Model.Etudiant;
import com.gestionStagiaires.GestionStagiaires.Repository.CandidatureRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

@Service //pour définir cette classe comme étant une classe contenant du code métier donc un service
@AllArgsConstructor //Pour demander à Lombok de créer un contructeur avec tous les champs qui sont dans cette classe
public class CandidatureServiceImpl implements CandidatureService{
    //couche métier

    private final CandidatureRepository candidatureRepository;
    private final EtudiantService etudiantService;
    private final EmployeurService employeurService;

    @Override
    public Candidature creer(Candidature candidature) {

        /*Employeur employeurElement = employeurService.getById(candidature.getEmployeur().getId());
        employeurElement.getCandidatures().add(candidature);
        Etudiant etudiantElement = etudiantService.getById(candidature.getEtudiant().getId());
        etudiantElement.getCandidatures().add(candidature);

        employeurService.modifier(employeurElement.getId(), employeurElement);
        etudiantService.modifier(etudiantElement.getId(), etudiantElement);*/

        return candidatureRepository.save(candidature);

    }

    @Override
    public List<Candidature> lire() {
        return candidatureRepository.findAll();
    }

    @Override
    public Candidature getById(Long id) {
        return candidatureRepository.findById(id).orElseThrow(() -> new RuntimeException("Candidature non trouvée !"));
    }

    @Override
    public Candidature modifier(Long id, Candidature candidature) {
        return candidatureRepository.findById(id)
                .map(c-> {
                    c.setCv(candidature.getCv());
                    c.setLettreDeMotivation(candidature.getLettreDeMotivation());
                    c.setEmployeur(candidature.getEmployeur());
                    c.setStatut(candidature.getStatut());
                    c.setEtudiant(candidature.getEtudiant());
                    c.setOffre(candidature.getOffre());
                    return candidatureRepository.save(c);
                }).orElseThrow(() -> new RuntimeException("Candidature non trouvée !"));
    }

    @Override
    public String supprimer(Long id) {
        candidatureRepository.deleteById(id);
        return "Candidature supprimée !";
    }

    @Override
    public int getId(String etudiantEmail, int offreId) {
        AtomicReference<Integer> candidatureId = new AtomicReference<>();
        candidatureRepository.findAll().forEach(candidatureElement -> {
            if(etudiantEmail.equals(candidatureElement.getEtudiant().getEmail()) && offreId == candidatureElement.getOffre().getId()) {
                    candidatureId.set(Math.toIntExact(candidatureElement.getId()));
            }
        });
        return candidatureId.get();
    }

}
